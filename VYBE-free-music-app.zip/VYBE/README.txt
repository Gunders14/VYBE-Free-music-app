VYBE — free music and talking DJ prototype

Open index.html in a browser or host it on a free static website host.

Music:
- Popular songs: searches Apple's public iTunes catalogue for available short previews.
- Independent music: searches Jamendo's API for tracks and streams the returned audio URL.
- A testing client ID is prefilled for experimentation only. Register at https://developer.jamendo.com/ and use your own client ID for regular use.
- Track licensing varies. Attribution/source links are shown where available; check the individual track licence and Jamendo API terms before redistributing, monetising, or using music publicly.

DJ:
- Uses the browser/device's built-in speech synthesis.
- DJ track choices are mood-based demo logic, not a cloud AI service.

This is a prototype, not a full Spotify replacement. Commercial full-length songs require an authorised music-provider agreement.
